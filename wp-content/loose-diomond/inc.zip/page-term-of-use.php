<?php

/**
 * Template Name: Terms of Use
 */

get_header();
?>

<!-- Shipping section start -->
<div class="privacy_policy_section mx-auto">
    <div class="banner_section">
        <div class="py_60 banner_inner mb_35">
            <div class="container">
                <div class="row">
                    <h1 class="fw-500">General Terms and Conditions of Sale</h1>
                    <p>Welcome to our website. At <?php echo get_site_url();?>, or any other loosegrowndiamond.com website
                        (collectively, the “Site“), we always appreciate your business. If you would like to provide
                        feedback about the Site or recommend a way we can improve the buying experience, please <a
                            href=""> click here.</a> In addition, we offer the loosegrowndiamond.com Safe Purchase
                        Guarantee (see here: <a href="<?php echo get_site_url();?>/faq/#Insurance_Care"> <?php echo get_site_url();?>/faq/#Insurance_Care </a>)
                        to ensure your comfort when buying on a Site.</p>
                    <p>“RRP Diamond” is a brand operated by Grown Diamond LLC <strong> (“Grown Diamond
                        LLC”, “we“, “our” or “us“) </strong>, which provides services to you subject to the terms
                        and conditions included in this General Terms and Conditions of Sale (“<strong> Terms
                        </strong>“) and other customer service pages which we have prepared to help make your
                        shopping experience with RRP Diamond as enjoyable and problem-free as possible.
                        Please read them carefully. By visiting or using the Site or any other RRP Diamond
                        service you acknowledge that you have read and understood, and agree to be bound by, these
                        Terms. You also agree to comply with all applicable laws and regulations, including,
                        without limitation, the applicable copyright and trademark laws and not to violate any
                        third-party rights. In addition, You agree that you will not use, sell or supply any
                        product(s) purchased from RRP Diamond in an unlawful manner and, in particular,
                        will comply with all export controls and sanctions rules. If you do not agree to these
                        Terms, please do not use the Site. Please note that we do not assume any responsibility or
                        liability for your reliance on any tax-estimation tool available on RRP Diamond’s
                        Site. By purchasing RRP Diamond products, you acknowledge that RRP Diamond’s approved payment processors will take your payment, and approved carriers will
                        deliver your order.</p>

                    <h2 class="fw-500">Privacy</h2>
                    <p>We collect certain data and information about you in connection with your purchase. Grown
                        Diamond LLC will use, store, and otherwise process such data and information in accordance
                        with our Privacy Policy. Please review the Privacy Policy, which also applies to your visit
                        to and use of the Site: <?php echo get_site_url();?>/privacy-policy/. You confirm that
                        any information submitted to us is true, complete, and accurate. Any breach of these Terms
                        and/or of the Privacy Policy may result in the suspension of your user account.</p>
                    <h2 class="fw-500">Ownership; Feedback and Copyright</h2>
                    <p>This Site is owned and operated by Grown Diamond LLC, doing business as “RRP Diamond.” Unless otherwise noted, all design and content included on this Site, including
                        text, graphics, logos, icons, images, artwork, audio, and video clips, and software is the
                        property of RRP Diamond (or is used under license to RRP Diamond) and, for
                        the avoidance of doubt, it is protected by applicable copyright and trademark laws, and
                        other laws and regulations.</p>
                    <p>To the extent you provide any feedback, comments, or suggestions to RRP Diamond in
                        connection with your use of the Site (“Feedback“), you acknowledge that any and all rights,
                        including intellectual property rights in such Feedback shall belong exclusively to RRP Diamond, and that such Feedback shall be considered confidential information and you
                        hereby irrevocably and unconditionally transfer and assign to RRP Diamond all
                        intellectual property rights in such Feedback, and waive any and all moral rights that you
                        may have with respect thereto. It is further understood that the use of Feedback, if any,
                        may be made by RRP Diamond at its sole discretion and that RRP Diamond in no
                        way shall be obliged to make use of any kind of the Feedback or part thereof.</p>

                    <p> Notwithstanding the foregoing, we appreciate hearing from our customers and welcome your
                        Feedback regarding RRP Diamond’s Site and the products offered for sale by RRP Diamond, provided that such Feedback is not illegal, obscene, threatening, defamatory,
                        invasive of privacy, infringements of intellectual property rights or otherwise
                        objectionable or injurious to third parties and does not contain or consist of viruses,
                        political campaigning, commercial solicitation, chain letters, mass mailings or any form of
                        “spam”. You may not use a false email address, impersonate any person, or otherwise mislead
                        us as to the origin of any Feedback.</p>

                    <p>If you do submit Feedback, you should be aware that RRP Diamond’s policies do not
                        permit us to accept or consider creative ideas, suggestions, inventions, or materials other
                        than those that we have specifically requested. RRP Diamond values your Feedback but
                        requests that you be specific in your comments and not submit creative ideas, inventions,
                        suggestions, or materials. RRP Diamond shall not be liable for any use or disclosure
                        of any such Feedback.</p>

                    <p>In addition, any violation of our intellectual property rights, including, without
                        limitation, of our Marks as described below, may result in account suspension, your
                        liability for damages incurred, injunctive relief, and/or any other potential legal action.
                    </p>
                    <h2 class="fw-500">Trademarks</h2>
                    <p>As between you and us, the RRP Diamond website, including its graphics, logos,
                        headers, icons, scripts, and service names, contains trademarks (“Marks”) of RRP Diamond. RRP Diamond’s Marks may not be used in connection with any product or
                        service that is not RRP Diamond’s, in any manner that is likely to cause confusion
                        among customers or potential customers, or in any manner that harms or discredits RRP Diamond. All other trademarks related to the products sold on this Site are the sole
                        property of their respective owners.</p>

                    <p>Nothing on this Site or in these Terms should be construed as any license or right to use any
                        Marks displayed on the Site without the express written permission of RRP Diamond or
                        the trademark or service mark owner. Neither the names “loosegrowndiamond.com” or “RRP Diamond” nor RRP Diamond’s logos may be used for any purpose without RRP Diamond’s prior written consent. RRP Diamond’s logos may not be used as a
                        “hot” link to any other website without RRP Diamond’s prior written consent.</p>
                    <h2 class="fw-500">Use of the Site</h2>
                    <p>The Site and content are intended solely for personal and non-commercial use by visitors and
                        online shoppers. Any use of any Site or its content other than for personal and
                        non-commercial purposes is prohibited. You agree not to reproduce, publish, transmit,
                        distribute, modify, create derivative works from, or commercially exploit in any way any of
                        the content of any Site.</p>

                    <p>You shall not: (a) use, modify, create derivative works of, transfer, reproduce, distribute,
                        display or disclose the content or use it for any commercial purpose, or any public display,
                        performance, sale, or rental, (b) decompile, reverse engineer, or disassemble the content,
                        (c) remove any copyright, trademark registration, or other proprietary notices from the
                        content, (d) disrupt servers or networks connected to the Site; (e) use or launch any
                        automated system (including without limitation, “robots” and “spiders”) to access the Site
                        or extract content or data from it, and/or (f) circumvent, disable or otherwise interfere
                        with security-related features of the Site or features that prevent or restrict use or
                        copying of any content or that enforce limitations on use of the Site. You further agree not
                        to access or use any Site in any manner that may be harmful to the operation of the Site or
                        its content.</p>


                    <h2 class="fw-500">Your Account and Placing an Order</h2>
                    <p> To place an order, you must open an account with us (“Your Account”) which will require you
                        to
                        provide some compulsory personal information. Alternatively, you can choose to place your
                        order
                        by logging in with your Facebook or Google accounts.</p>

                    <p> You are not legally obligated to provide us with personal information, and you hereby
                        confirm
                        that providing us personal information is of your own free will. You confirm that all
                        information and details provided by you (including upon registration) are true, accurate and
                        up
                        to date in all respects and at all times.</p>

                    <p>When you create an account we may provide you with and/or ask you to use passwords or other
                        means to allow you to access certain areas of the website and/or to maintain your account
                        security. If you access or use any Site, you are responsible for maintaining the
                        confidentiality
                        of your account and for restricting access to your computer. You agree to be responsible for
                        all
                        activities that occur under Your Account or password. If you are under 18 years old, you may
                        use
                        loosegrowndiamond.com only with the involvement of a parent or guardian. RRP Diamond
                        reserves the right to refuse service, terminate accounts, remove or edit content or cancel
                        orders in its sole discretion. If RRP Diamond is suspicious of any fraudulent
                        activity
                        coming from your account, it can reserve the right to refuse you access to your Account and
                        can
                        delete the account.</p>
                    <h2 class="fw-500">Acceptance of your Order</h2>
                    <p>Please note that completion of the online checkout process does not constitute our acceptance
                        of your offer to purchase products or services from us. We will notify you by email as soon
                        as possible to acknowledge that we have received and are processing your order
                        (“Confirmation Notice”). Loose diamonds are shipped 1-4 days after payment, though certain
                        diamonds may be shipped up to 14 days after payment, and all other jewelry and engagement
                        rings will be shipped in 1-3 weeks, depending on the production schedule of that item. Prior
                        to dispatch of the product(s), RRP Diamond has the right to decline an order at its
                        discretion and for any reason (for example, this may happen for legal or regulatory reasons
                        or for reasons related to availability or stock). To the maximum extent permitted by law,
                        RRP Diamond shall have no liability to you as a result of such refusal of any such
                        order submitted.</p>

                    <p>If we cannot supply you with the product or service you ordered, we will not process your
                        order and inform you of this in writing (via email) and, if you have already paid for the
                        product, we will refund you in full as soon as reasonably possible, but in any event no
                        later than 14 days after receipt of your payment.</p>
                    <h2 class="fw-500">Delivery</h2>
                    <p>RRP Diamond may choose the carriers at its discretion. Delivery charges and
                        timescales vary depending on the type of products ordered, the service you select, and the
                        delivery address.</p>

                    <p> Please note that certain products and services may be subject to alternative delivery
                        charges, restrictions, and/or timescales. If delivery cannot be made to a customer due to
                        the customer not being present at the address at the time allotted by the carrier or if a
                        customer refuses to accept the products, RRP Diamond reserves the right to deduct
                        the cost for returning products to the RRP Diamond returns center from the
                        customer’s refund for the order.</p>

                    <p>All risks in the products you order (including the risk of loss and/or damage to the
                        products) shall pass to you when they are delivered to the delivery address specified in
                        your order.</p>

                    <p>Where the supply of your product(s) or service(s) is delayed or prevented for reasons
                        beyond our control (for example, material shortages, import delays or higher than
                        anticipated demand) we will make every effort to keep you informed but, to the maximum
                        extent permitted by law, shall be under no liability to you for such delay or failure. For
                        the avoidance of doubt, this paragraph does not exclude or affect in any way any statutory
                        right that is afforded to you to cancel an order when a product is delayed or not provided.
                    </p>

                    <h3 class="fw-500">Return Policy, Free Resize &amp; Warranty</h3>
                    <p>You may have cancellation and return rights under applicable local laws. Nothing in these
                        Terms affects your statutory rights.</p>
                    <p>In addition to your statutory rights, RRP Diamond offers the following customer
                        benefits:</p>
                    <div>
                        <ul>
                            <li><strong><?php echo RETURN_DAYS; ?>-Day Returns:</strong> Eligible products may be returned within
                                <strong><?php echo RETURN_DAYS; ?> days</strong> of delivery, subject to our Return Policy. Certain
                                products, including custom-made, engraved, or otherwise non-returnable items, may
                                be excluded. Please refer to our Return Policy for full details.</li>
                            <li><strong>Free Ring Resize:</strong> We offer <strong>one complimentary resize</strong>
                                for eligible rings within <strong><?php echo RETURN_DAYS; ?> days</strong> of delivery. Certain wedding
                                bands may not be eligible. Please refer to our Resize Policy for complete
                                eligibility requirements and exclusions.</li>
                            <li><strong>Warranty:</strong> We provide a <strong><?php echo RETURN_DAYS; ?>-day limited warranty</strong>
                                covering manufacturing defects, including loose prongs, polishing, and rhodium
                                plating. The warranty does not cover normal wear and tear, accidental damage,
                                misuse, or repairs performed by third parties. Please refer to our Warranty Policy
                                for complete coverage and exclusions.</li>
                        </ul>
                    </div>
                    <p>For complete details regarding eligibility, exclusions, and instructions for returns,
                        resizing, or warranty claims, please visit our dedicated <strong>Return Policy</strong>,
                        <strong>Resize Policy</strong>, and <strong>Warranty Policy</strong> pages, or contact us at
                        <strong><?php echo SUPPORT_EMAIL;?></strong>.</p>

                    <h2 class="fw-500">Your Right to Cancel and Refunds</h2>
                    <p>You may have cancellation rights governed by local legislation. Nothing in these Terms will
                        affect these statutory rights.</p>



                    <h2 class="fw-500">Damaged or Incorrectly Supplied Products</h2>
                    <p>You should check all products you receive against your order. If the products you receive are
                        damaged or incorrectly supplied on delivery then you must note the details of any damage or
                        error in supply on the delivery documentation or if you are unable to view the items on
                        receipt, you must inform us (by sending an email to <?php echo SUPPORT_EMAIL;?>) within a
                        reasonable period of time. You must return the products to us as soon as possible after
                        informing us that the products are damaged or have been incorrectly supplied.</p>

                    <h2 class="fw-500">Ownership of User Submissions</h2>
                    <p>You represent and warrant that you own or have the necessary rights and permissions to use
                        and authorize RRP Diamond to use all intellectual property rights in and to your
                        User Submissions and to enable inclusion and use thereof as contemplated by the Site and
                        these Terms. You retain all of your ownership rights in and to your User Submissions.</p>

                    <h2 class="fw-500">Product Descriptions</h2>
                    <p>RRP Diamond makes all reasonable efforts to display the products listed for sale on
                        its Site as accurately as possible. However, the colors we use, as well as the display and
                        color capabilities of your computer monitor, will affect the colors that you actually see on
                        your screen. RRP Diamond cannot guarantee that your monitor’s display of any product
                        color, texture, or detail will be accurate. In addition, RRP Diamond does not
                        warrant that product description or other content is accurate, complete, reliable, current,
                        or error-free. While RRP Diamond makes every effort to ensure that our products are
                        described and priced accurately, in the event that an item is deemed to be priced
                        incorrectly, RRP Diamond reserves the right to refuse the sale of that item. If the
                        pricing error is discovered after payment has been finalized, RRP Diamond reserves
                        the right to cancel the sale and refund the transaction in full. If a product offered by
                        RRP Diamond is not as described, your sole remedy is to return it in unused
                        condition. All items are subject to availability. We will inform you as soon as possible if
                        the product(s) you have ordered are not available.</p>

                    <h2 class="fw-500">Other Sites</h2>
                    <p>The Site contains links to websites that are not maintained by RRP Diamond. We try to
                        include links to only those websites that are in good taste and safe for our visitors, but
                        we are not responsible for the content or accuracy of any websites other than our own and
                        cannot guarantee that such websites will not change without our knowledge. The inclusion of
                        a link in this Site does not imply RRP Diamond’s endorsement of the website. If you
                        decide to use any links to access other websites, you do so at your own risk.</p>
                    <h2 class="fw-500">Disclaimer of Warranties and Limitation of Liability</h2>
                    <p> Nothing in these Terms limits or excludes our liability for any matter that cannot be
                        limited or
                        excluded by applicable law. Nothing in these Terms will affect your statutory rights.</p>

                    <p> EXCEPT AS EXPRESSLY PROVIDED IN THESE TERMS, THE MATERIALS AND INFORMATION PROVIDED BY RRP DIAMOND ON THE SITE ARE PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS. RRP DIAMOND MAKES NO REPRESENTATIONS OR WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, AS TO THE
                        OPERATION OF ITS SITE OR THE INFORMATION, CONTENT, MATERIALS, OR PRODUCTS INCLUDED ON ITS
                        SITE.
                        YOU AGREE THAT YOUR ACCESS TO, AND USE OF THE SITES IS AT YOUR OWN RISK. RRP DIAMOND
                        EXPRESSLY DISCLAIMS ANY RESPONSIBILITY AND LIABILITY FOR THE ACCURACY OF, AND YOUR RELIANCE
                        ON,
                        THE TAX-ESTIMATION TOOL AVAILABLE ON RRP DIAMOND’S SITE AND ANY ASPECTS RELATED
                        THERETO.
                        V, ITS AFFILIATES, AND SUPPLIERS DO NOT GUARANTEE OR REPRESENT THAT YOUR USE OF THE
                        TAX-ESTIMATION TOOL WILL SATISFY OR ENSURE COMPLIANCE WITH ANY LEGAL OBLIGATIONS OR LAWS OR
                        REGULATIONS. RRP DIAMOND IS NOT IN THE BUSINESS OF PROVIDING LEGAL, FINANCIAL,
                        ACCOUNTING, TAX, OR RELATED ADVICE OR SERVICES. TO THE FULLEST EXTENT PERMISSIBLE BY
                        APPLICABLE
                        LAW, RRP DIAMOND DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, WITHOUT
                        LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
                        RRP DIAMOND DOES NOT WARRANT THAT THE SITE, ITS SERVERS, OR EMAILS SENT FROM RRP DIAMOND ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. RRP DIAMOND WILL NOT BE
                        LIABLE
                        FOR ANY DAMAGES OF ANY KIND ARISING FROM THE USE OF THIS SITE, INCLUDING, WITHOUT
                        LIMITATION,
                        INDIRECT, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGES.</p>

                    <p> EXCEPT AS EXPRESSLY PROVIDED IN THESE TERMS, WE EXCLUDE ALL REPRESENTATIONS, WARRANTIES,
                        CONDITIONS, AND TERMS (WHETHER EXPRESS OR IMPLIED BY STATUTE, COMMON LAW, OR OTHERWISE) TO
                        THE
                        FULLEST EXTENT PERMITTED BY LAW, INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OR
                        CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, QUIET
                        POSSESSION, NON-INFRINGEMENT, TITLE, QUALITY OF SERVICE, OR THAT OTHERWISE ARISE FROM A
                        COURSE
                        OF PERFORMANCE OR DEALING, OR USAGE OF TRADE, ALL OF WHICH ARE HEREBY DISCLAIMED BY RRP DIAMOND AND ITS LICENSORS AND SUPPLIERS.</p>

                    <p> YOU MUST FOLLOW ANY ADVICE OR INSTRUCTIONS WE GIVE YOU TO KEEP THE PRODUCTS WE SUPPLY TO YOU
                        SAFE (INCLUDING ANY INSTRUCTIONS OR PRODUCT MANUALS PROVIDED WITH THE PRODUCTS). WE CANNOT
                        ACCEPT LIABILITY FOR DAMAGE TO PRODUCTS WE HAVE SUPPLIED WHICH IS CAUSED BY YOUR FAILURE TO
                        FOLLOW THIS ADVICE.</p>

                    <p> IN ANY EVENT, WE WILL NOT BE LIABLE FOR ANY CONSEQUENTIAL, INDIRECT, SPECIAL, INCIDENTAL, OR
                        PUNITIVE DAMAGES OR LOSSES RELATED TO ANY BUSINESS OF YOURS INCLUDING (WITHOUT LIMITATION)
                        LOST
                        DATA, LOST PROFITS, LOST REVENUES, OR BUSINESS INTERRUPTION. THE AGGREGATE LIABILITY OF
                        RRP DIAMOND UNDER, OR OTHERWISE IN CONNECTION WITH, THESE TERMS SHALL NOT EXCEED THE
                        AMOUNT
                        ACTUALLY PAID BY THE CUSTOMER TO RRP DIAMOND UNDER THE PURCHASE ORDER IN WHICH THE
                        LIABILITY AROSE.</p>

                    <p> THE FOREGOING EXCLUSIONS AND LIMITATIONS SHALL APPLY EVEN IF RRP DIAMOND HAS BEEN
                        ADVISED, OR SHOULD HAVE BEEN AWARE, OF THE POSSIBILITY OF LOSSES, DAMAGES, OR COSTS, EVEN IF
                        ANY
                        REMEDY IN THESE TERMS FAILS OF ITS ESSENTIAL PURPOSE; AND REGARDLESS OF THE THEORY OR BASIS
                        OF
                        LIABILITY, INCLUDING WITHOUT LIMITATION FUNDAMENTAL BREACH, NEGLIGENCE, MISREPRESENTATION,
                        STRICT LIABILITY OR OTHER CONTRACT OR TORT LIABILITY.</p>

                    <p> This disclaimer of liability applies to any damages or injury caused by any failure or
                        performance, error, omission, interruption, deletion, defect, delay in operation or
                        transmission, computer virus, an act of God, communication line failure, theft or
                        destruction,
                        or unauthorized access to, alteration of, or use of records, whether for breach of contract,
                        tortious behavior, negligence, or under any other cause of action. You also specifically
                        acknowledge that RRP Diamond is not liable for your defamatory, offensive,
                        infringing,
                        or illegal materials or conduct or that of third parties.</p>

                    <p> The law of certain States may not allow limitations on warranties or damages as described
                        above.
                        If such law applies to you, some or all of the above disclaimers, exclusions, or warranties
                        may
                        not apply to you and you may have additional rights.</p>
                    <h2 class="fw-500">Assignment</h2>
                    <p>You may not assign or sub-contract any of your rights or obligations under these Terms to any
                        third party unless we agree in writing. We may assign, transfer, delegate or sub-contract
                        any of our rights or obligations under these Terms to any third party at our discretion
                        without any restriction of any kind and without your consent. To the maximum extent
                        permitted by law, no third party shall be entitled to enforce any of these Terms.</p>
                    <h2 class="fw-500">Applicable Law; General</h2>
                    <p> To the maximum extent permitted by law, you agree that the law of New York State, without
                        regard to principles of conflict of laws, shall govern these Terms and any dispute that may
                        arise between you and RRP Diamond. If any court of competent jurisdiction determines
                        that any provision, or any portion thereof, contained in these Terms is unenforceable in any
                        respect, such provision shall be deemed limited to the extent that such court deems it
                        enforceable, and as so limited shall remain in full force and effect. If such court shall
                        deem any such provision, or portion thereof, wholly unenforceable, the remaining provisions
                        of these Terms shall nevertheless remain in full force and effect. These Terms, together
                        with the Privacy Policy, constitute the entire agreement between you and RRP Diamond
                        relating to your access to and use of the Site.</p>

                    <p> The rights and remedies of RRP Diamond set forth in these Terms are not exclusive
                        of, but are cumulative to, any rights or remedies now or subsequently existing at law, in
                        equity, by statute or otherwise.</p>

                    <p> No relaxation or delay by us in exercising any right or remedy under these Terms shall
                        operate as waiver of that right or remedy or shall affect our ability to subsequently
                        exercise that right or remedy. Any waiver must be agreed by us in writing.</p>
                    <h2 class="fw-500">Dispute Resolution</h2>
                    <p><strong>Binding Arbitration; Class Action Waiver.</strong> PLEASE READ THIS SECTION
                        CAREFULLY, AS IT AFFECTS YOUR LEGAL RIGHTS. You and Grown Diamond LLC agree that any
                        dispute, claim, or controversy arising out of or relating to these Terms, your use of the
                        Site, or any products or services purchased through the Site shall be resolved exclusively
                        through final and binding arbitration, rather than in court, except that either party may
                        bring an individual claim in small claims court. The arbitration shall be conducted by
                        [JAMS / AAA — to be selected by counsel] under its applicable rules then in effect.</p>

                    <p>YOU AND GROWN DIAMOND LLC AGREE THAT EACH MAY BRING CLAIMS AGAINST THE OTHER ONLY IN YOUR OR
                        ITS INDIVIDUAL CAPACITY, AND NOT AS A PLAINTIFF OR CLASS MEMBER IN ANY PURPORTED CLASS OR
                        REPRESENTATIVE PROCEEDING. Unless both you and Grown Diamond LLC agree otherwise, the
                        arbitrator may not consolidate more than one person’s claims and may not otherwise preside
                        over any form of a representative or class proceeding.</p>

                    <p>You have the right to opt out of this arbitration agreement within <?php echo RETURN_DAYS; ?> days of first
                        accepting these Terms by sending written notice to <?php echo SUPPORT_EMAIL;?> with the
                        subject line “Arbitration Opt-Out,” including your name and order/account information.</p>

                    <p><em>Note: This is placeholder language only. Arbitration provider selection, opt-out
                        windows, and conspicuous-disclosure formatting requirements differ by state — this section
                        must be finalized by counsel before publishing, and is especially important given TCPA
                        claims (from the SMS program) are frequently brought as class actions.</em></p>

                    <h2 class="fw-500">Modification</h2>
                    <p>RRP Diamond reserves the right, in its sole discretion, to change, modify, add, or
                        remove portions of these Terms at any time. Please check this page periodically for changes.
                        You agree that each time you visit any Site, your visit to and use of such Site will be
                        subject to and bound by the then current version of these Terms.</p>
                    <h2 class="fw-500">Payment Terms</h2>
                    <p> (a) <span class="text-decoration-underline"> Payment Processing </span>: RRP Diamond
                        provides international payment processing and
                        order fulfillment through one of its designated service providers Stripe, Afterpay, Klarna
                        or Splitit as the Merchants-of-Record. When placing an order through the Site, your order
                        will be processed using Payment Gateway checkout and payment processing services, and you
                        acknowledge and agree that: (i) your payment transaction will be processed via Payment
                        Gateway, not RRP Diamond, and (ii) upon successful verification and authentication
                        by Payment Gateway of payment information provided by you, Payment Gateway will accept the
                        transaction, and purchase the products from RRP Diamond for the sole purpose of
                        reselling such products to you at a price equal to the amounts presented to and agreed-upon
                        by you. Payment Gateway will provide the merchant or RRP Diamond with its own
                        payment information to purchase the products you have ordered, and Payment Gateway will
                        resell such products to you and bill the payment information you have provided. Payment
                        Gateway acquires temporary title to the products when the products exit the jurisdiction of
                        RRP Diamond. After Payment Gateway purchases and takes title to products from RRP Diamond to fulfill an order you have placed, you take title from Payment Gateway
                        before the products enter the jurisdiction that you have designated as your address for
                        delivery. All items purchased from Payment Gateway are made pursuant to a shipment contract.
                        In the event of any disparity or inconsistency between the terms of any shipment contract or
                        order fulfilment terms and these Terms, the terms of these Terms shall prevail to the extent
                        required to resolve the disparity or inconsistency.</p>

                    <p>(b) <span class="text-decoration-underline">Billing </span>: If you provide a credit card as
                        your tender type, your credit card will be
                        billed by Payment Gateway, and charges to your account will be accompanied by the descriptor
                        “RRP Diamond” or “LGD” as applicable, (or such other descriptor as the Payment
                        Gateway may deploy), which denotes the Payment Gateway system, and that the Payment Gateway
                        is the supplier whose products you have purchased through Payment Gateway. If you paid using
                        your PayPal account, charges to your account will be accompanied by the descriptor “RRP Diamond” (or such other descriptor as Payment Gateway may deploy). In either case, you
                        will only be billed after your products have been received, processed and dispatched for
                        delivery by Payment Gateway. In the event of the receipt of any parcel from RRP Diamond containing only part of an order, Payment Gateway will process the products
                        received, and will only bill for an amount commensurate with the price of the products
                        therein, pro-rated amounts for shipping and/or handling, plus any duty, taxes, VAT (unless
                        Payment Gateway and RRP Diamond offered, and you accepted, the option of having your
                        order shipped DAP (‘delivered at place’)). Notwithstanding the foregoing, in the event of an
                        order being fulfilled by RRP Diamond in multiple parcels, unless expressly consented
                        to by you, in no instance will the aggregate amount billed to you by Payment Gateway exceed
                        the total amount presented at the time of order placement by you. If there is a technical
                        error in the Payment Gateway system which processes or accepts a transaction at an exchange
                        rate which is manifestly off-market, that transaction shall be void.</p>

                    <p>(c) Prices for the products are available at <?php echo get_site_url();?>, but duty charges,
                        VAT, taxes or surcharges levied or charged by the other country in an international order
                        may be applied at the discretion of customs (and these charges differ from country to
                        country and are the customer’s responsibility). Applicable sales taxes will be charged
                        depending on your region. You may pay by PayPal and all major credit cards. The availability
                        of a certain payment method may depend on your geographical location. RRP Diamond
                        may change the prices and the payment methods at any time but this will not affect orders
                        with respect to which we have already sent you a Confirmation Notice.</p>

                    <p>Customers paying by wire will receive wiring instructions once they have completed the
                        check-out process. We must receive confirmation from our bank that a wire transfer has been
                        completed before items can be shipped. At our sole discretion, we may require bank wire
                        payment for any international order or orders in excess of $20,000.</p>

                    <p>If you place an order on our Site, then you acknowledge and agree that: (i) RRP Diamond will charge you through the payment method you have selected for your order and such
                        other amounts that may accrue in connection with the order; (ii) that you will provide valid
                        and current information for (a) yourself and (b) if applicable, another person, but only if
                        you have first obtained their express consent or have the relevant rights to do so; (iii)
                        that RRP Diamond may use tools, software or services of payment processors to
                        process transactions on their behalf; and (iv) if your payment is not received by RRP Diamond for any reason from your card issuer, you agree to promptly pay all amounts
                        due upon request.</p>

                    <h3 class="fw-500">SMS Terms of Service</h3>
                    <p>By providing your mobile phone number and opting in through our website sign-up form,
                        pop-up, or checkout field, you agree to receive recurring automated marketing text messages
                        (including cart-abandonment reminders, promotions, and product updates) from RRP Diamond (operated by Grown Diamond LLC) and its SMS platform provider, Attentive, at the
                        number provided. Consent to receive marketing text messages is not a condition of any
                        purchase.</p>
                    <p>Message and data rates may apply. Message frequency varies. Reply STOP at any time to
                        unsubscribe; you will receive a one-time confirmation message. Reply HELP for assistance, or
                        contact us at <?php echo SUPPORT_EMAIL;?>. Carriers are not liable for delayed or
                        undelivered messages.</p>
                    <p>This SMS program is governed by our Terms of Use and Privacy Policy, available at
                        <a href="/terms-of-use/"><?php echo get_site_url();?>/terms-of-use/</a>
                        and
                        <a href="/privacy-policy/"><?php echo get_site_url();?>/privacy-policy/</a>.
                        For details on how your information is used and shared, please review our Privacy Policy.</p>

                    <h2 class="fw-500">Date of Last Update of these Terms: July 13, 2026.</h2>
                    <p>RRP Diamond’s website(s) are operated by Grown Diamond LLC from its offices at 55W
                        47th St., Suite #790, New York, NY-10036, USA. Grown Diamond LLC makes no representations
                        that the contents of any of its websites are appropriate or available for use in other
                        locations. Visitors who choose to access any RRP Diamond web site from other
                        locations do so on their own initiative and are responsible for compliance with applicable
                        local law.</p>

                    <p class="m-0">Once again, we thank you for your interest in RRP Diamond. We hope that your
                        experience
                        at any RRP Diamond web site is enjoyable.</p>

                </div>

            </div>
        </div>
    </div>
</div>
<!-- Shipping section end -->

<?php
get_footer();