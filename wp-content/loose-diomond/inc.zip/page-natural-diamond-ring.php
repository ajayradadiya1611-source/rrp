<?php
/**
 * Template Name: Natural Diamond Ring
 *
 * Ported from the old theme's "Natural Diamond Ring (LS)" template.
 * The quote form posts to the existing REST route /wp-json/ls/v1/ask-us.
 *
 * Images/video are read from  <theme>/rrp-img/natural-diamond-ring/  :
 *   hero-bg.jpg, Deccans.png, checkersaga-logo.png, age.png, banner-video.mp4,
 *   Review3.jpg, Review2.jpg, Review1.jpg, Review5.jpg,
 *   Customer1.webp, Customer2.webp, Customer4.webp, TrustPilot-review-btn.svg,
 *   icon-2.svg, icon-1-1.svg, Arrow.svg, Order.svg, Call.svg, Ship.svg
 */

get_header();

$img = get_template_directory_uri() . '/rrp-img/natural-diamond-ring/';

$reviews = [
    [ 'Perfect! I love this ring.', 'Perfect! I love this ring. It has so much sparkle for such a dainty ring! Complements my other rings really well! Exactly what I wanted!! This came quickly and is great quality! Ships via UPS requires someone to be present at delivery, it can be tricky to receive if you are not at home all day. Make sure to use UPS tracking to know when you should be home.', 'Victoria Calva', 'Madrid, Spain', 'Customer1.webp' ],
    [ 'My fiancée and I are so happy...', 'My fiancée and I are so happy with our experiences through RRP Diamond. The service has been wonderful and the quality is exceptional. Thank you so much for ensuring quality product and happy customers. It’s nice to shop for something like this, without feeling the pressure to buy, and the pushiness from a sales person. We truly appreciate what you guys do!', 'Ravi Desai', 'Dubai, UAE', 'Customer2.webp' ],
    [ 'My ring is so beautiful!', 'My ring is so beautiful! The quality of ring is amazing and the picture doesn’t do it justice. I also really love the engraving option! It looked great. It is exactly what I had in mind. Shipping was extremely fast, I had the ring in less than a week I highly recommend buying jewelry from RRP, you wont be disappointed. I will definitely be shopping here come anniversary time!', 'Jenny L', 'Boston, USA', 'Customer4.webp' ],
];
$steps = [
    [ 'Order.svg', 'Ask for Free Quote', 'Ask us for a free quote with your desired jewelry design and we will send it to you.' ],
    [ 'Call.svg',  'Make a Payment',     'Once you have finalized the design and agree with the price, proceed to make the payment.' ],
    [ 'Ship.svg',  'Relax While We Ship', 'Once the payment has been made, relax and track your ring.' ],
];
?>
<main id="main" class="ndr">

    <!-- Hero -->
    <section class="ndr-hero" style="background-image:url('<?php echo esc_url( $img . 'hero-bg.jpg' ); ?>');">
        <div class="container">
            <h1 class="ndr-hero__title">Looking for a Ring at<br><span class="ndr-hero__tag">lowest rate</span> in the<br>world?</h1>
            <p class="ndr-hero__sub">You’re at the right Place.</p>
        </div>
    </section>

    <!-- Featured in -->
    <section class="ndr-featured">
        <div class="container">
            <h2 class="ndr-ttl">We’ve been featured in</h2>
            <div class="row align-items-center text-center row-gap-3">
                <div class="col-md-4"><img class="img-fluid" src="<?php echo esc_url( $img . 'Deccans.png' ); ?>" alt="Deccan Chronicle" loading="lazy"></div>
                <div class="col-md-4"><img class="img-fluid" src="<?php echo esc_url( $img . 'checkersaga-logo.png' ); ?>" alt="Checkersaga" loading="lazy"></div>
                <div class="col-md-4"><img class="img-fluid" src="<?php echo esc_url( $img . 'age.png' ); ?>" alt="The Asian Age" loading="lazy"></div>
            </div>
        </div>
    </section>

    <!-- Video -->
    <section class="ndr-video">
        <video autoplay loop muted playsinline>
            <source src="<?php echo esc_url( get_template_directory_uri(). '/rrp-img/why-choose/loose-grown-diamond-banner-video.mp4' ); ?>" type="video/mp4">
        </video>
    </section>

    <!-- Quote form -->
    <section class="ndr-req section">
        <div class="container text-center">
            <h2 class="ndr-ttl">Ask For A Free Quote For Your Ring</h2>
            <p class="ndr-sub">Fill in the form below and we will give you a quote, It’s Free</p>

            <form class="ndr-form" id="dimond_ring_request" novalidate>
                <div class="row row-gap-3">
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="first-name" placeholder="First name">
                        <small class="text-danger text-start d-block" data-err="first-name"></small>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="last-name" placeholder="Last name">
                        <small class="text-danger text-start d-block" data-err="last-name"></small>
                    </div>
                    <div class="col-md-6">
                        <input type="tel" class="form-control" name="phone" placeholder="Mobile Number">
                        <small class="text-danger text-start d-block" data-err="phone"></small>
                    </div>
                    <div class="col-md-6">
                        <input type="email" class="form-control" name="email" placeholder="Your email">
                        <small class="text-danger text-start d-block" data-err="email"></small>
                    </div>
                    <div class="col-12">
                        <textarea class="form-control" name="message" rows="4" placeholder="Your message"></textarea>
                        <small class="text-danger text-start d-block" data-err="message"></small>
                    </div>
                </div>
                <input type="hidden" name="reference_url" value="<?php echo esc_url( get_permalink() ); ?>">
                <button type="submit" class="ndr-form__btn">Ask for quote</button>
                <p class="ndr-form__msg text-success" id="ndr-success" hidden></p>
                <p class="ndr-form__msg text-danger" id="ndr-error" hidden></p>
            </form>
        </div>
    </section>

    <!-- Jewellery made by us -->
    <section class="ndr-made section">
        <div class="container text-center">
            <h2 class="ndr-ttl">Jewelry made by us</h2>
            <p class="ndr-sub">Here are some of the jewelry pieces made by us for our international customers</p>
        </div>
        <div class=" px-0">
            <div class="row g-1 mx-0">
                <?php foreach ( [ 'Review3.jpg', 'Review2.jpg', 'Review1.jpg', 'Review5.jpg' ] as $file ) : ?>
                    <div class="col-6 col-md-3"><img class="img-fluid w-100" src="<?php echo esc_url( $img . $file ); ?>" alt="Jewellery made by RRP Diamond" loading="lazy"></div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<div class="bg_light_gray">
   <div class="section">
        <?php echo single_product_what_customer_say(); ?>
    </div>
</div>
    <div class="section">
        <div class="container-fluid">
            <h2 class="h1 fw-600 text-center">HOW YOU GET LOWEST PRICE?</h2>
            <p class="font_size_15 text-center mb_70 text-dark">Our prices are lower than others, because we have our own diamond manufacture company called RRP Diamond and it’s all we give you directly. No Middleman.

            </p>
            <div class="etheme_step_row">
                <div class="row">
                    <div class="col-md-4">
                        <div class="etheme_box_m text-center">
                            <div>
                                <img src="<?php echo get_template_directory_uri(); ?>/rrp-img/comman/logo.svg" alt="loosegrowndiamond_logo">
                                <div class="text_black_secondary fw-600 my-2 h5">RRP Diamond + Jeweler</div>
                                <span class="font_size_15">(We as a Manufacturer) </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="etheme_box_m etheme_white_box text-center">
                            <div>
                                <p class="text_black_secondary fw-500 mb-0">Directly Selling To</p>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/image/logo/arrow_1.svg" alt="arrow_1">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="etheme_box_m text-center">
                            <div>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/image/logo/user.svg" alt="user">
                                
                                <div class="text_black_secondary fw-600 my-2 h5">You (as Buyer)  </div>
                                <span class="font_size_15">(Customer like You) </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- How to order -->
    <div class="bg_light_gray">
        <section class="ndr-order section">
            <div class="container text-center">
                <h2 class="ndr-ttl">How to order</h2>
                <div class="row row-gap-4">
                    <?php foreach ( $steps as $s ) : ?>
                        <div class="col-md-4">
                            <img src="<?php echo esc_url( $img . $s[0] ); ?>" alt="" loading="lazy">
                            <h5><?php echo esc_html( $s[1] ); ?></h5>
                            <p><?php echo esc_html( $s[2] ); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </div>
</main>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('dimond_ring_request');
    if (!form) return;

    var ok  = document.getElementById('ndr-success');
    var bad = document.getElementById('ndr-error');
    var btn = form.querySelector('.ndr-form__btn');

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var v = function (n) { var el = form.elements[n]; return el ? el.value.trim() : ''; };

        var errs = {};
        if (!v('first-name')) errs['first-name'] = 'Required';
        if (!v('last-name'))  errs['last-name']  = 'Required';
        if (!v('phone'))      errs.phone = 'Required';
        else if (!/^\+?[0-9\s\-()]{7,20}$/.test(v('phone'))) errs.phone = 'Enter a valid phone number';
        if (!v('email')) errs.email = 'Required';
        else if (!/^\S+@\S+\.\S+$/.test(v('email'))) errs.email = 'Enter a valid email';
        if (!v('message')) errs.message = 'Required';

        form.querySelectorAll('[data-err]').forEach(function (el) {
            el.textContent = errs[el.getAttribute('data-err')] || '';
        });
        ok.hidden = bad.hidden = true;
        if (Object.keys(errs).length) return;

        var body = new URLSearchParams();
        body.set('name', v('first-name') + ' ' + v('last-name'));
        body.set('email', v('email'));
        body.set('phone', v('phone'));
        body.set('message', v('message'));
        body.set('reference_url', v('reference_url'));

        btn.disabled = true;
        fetch(<?php echo wp_json_encode( rest_url( 'ls/v1/ask-us' ) ); ?>, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body
        })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
            if (res.ok) {
                ok.textContent = 'Thank you for your enquiry. We will be in touch shortly.';
                ok.hidden = false;
                form.reset();
            } else {
                bad.textContent = (res.j && res.j.error) || 'Something went wrong. Please try again.';
                bad.hidden = false;
            }
        })
        .catch(function () {
            bad.textContent = 'Something went wrong. Please try again.';
            bad.hidden = false;
        })
        .finally(function () { btn.disabled = false; });
    });
});
</script>
<?php get_footer(); ?>
