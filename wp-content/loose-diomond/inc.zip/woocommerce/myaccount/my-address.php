<?php
/**
 * My Addresses
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/my-address.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$customer_id = get_current_user_id();

if ( ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ) {
	$get_addresses = apply_filters(
		'woocommerce_my_account_get_addresses',
		array(
			'shipping' => __( 'Shipping address', 'woocommerce' ),
			'billing'  => __( 'Billing address', 'woocommerce' ),
			
		),
		$customer_id
	);
} else {
	$get_addresses = apply_filters(
		'woocommerce_my_account_get_addresses',
		array(
			'billing' => __( 'Billing address', 'woocommerce' ),
		),
		$customer_id
	);
}

$oldcol = 1;
$col    = 1;
?>

<p>
	<?php echo apply_filters( 'woocommerce_my_account_my_address_description', esc_html__( 'The following addresses will be used on the checkout page by default.', 'woocommerce' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</p>

<?php if ( ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ) : ?>
	<div class="u-columns woocommerce-Addresses col2-set addresses">
<?php endif; ?>

<?php foreach ( $get_addresses as $name => $address_title ) : ?>
	<?php
		$address = wc_get_account_formatted_address( $name );
		$col     = $col * -1;
		$oldcol  = $oldcol * -1;
	?>

	<div class="u-column<?php echo $col < 0 ? 1 : 2; ?> col-<?php echo $oldcol < 0 ? 1 : 2; ?> woocommerce-Address">
		<header class="woocommerce-Address-title title">
			<h2><?php echo esc_html( $address_title ); ?></h2>
			<a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address', $name ) ); ?>" class="edit">
				<?php echo $address ? esc_html__( 'Edit', 'woocommerce' ) : esc_html__( 'Add', 'woocommerce' ); ?>
			</a>
		</header>
		<address>
			<?php
				if ( $address ) {
					$first_name = get_user_meta($customer_id, $name.'_first_name', true);
					$last_name  = get_user_meta($customer_id, $name.'_last_name', true);
					$address1   = get_user_meta($customer_id, $name.'_address_1', true);
					$address2   = get_user_meta($customer_id, $name.'_address_2', true);
					$country    = get_user_meta($customer_id, $name.'_country', true);
					$state      = get_user_meta($customer_id, $name.'_state', true);
					$city       = get_user_meta($customer_id, $name.'_city', true);

					echo '<strong>Name:</strong> '.esc_html($first_name.' '.$last_name).'<br/>';
					echo '<strong>Address:</strong> '.esc_html($address1).'<br/>';
					echo '<strong>Address2:</strong> '.esc_html($address2).'<br/>';
					echo '<strong>Country:</strong> '.esc_html($country).'<br/>';
					echo '<strong>State:</strong> '.esc_html($state).'<br/>';
					echo '<strong>City:</strong> '.esc_html($city).'<br/>';

				} else {
					echo esc_html__( 'You have not set up this type of address yet.', 'woocommerce' );
				}

				/**
				 * Used to output content after core address fields.
				 *
				 * @param string $name Address type.
				 * @since 8.7.0
				 */
				do_action( 'woocommerce_my_account_after_my_address', $name );
			?>
		</address>
	</div>

<?php endforeach; ?>

<?php if ( ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ) : ?>
	</div>
	<?php
endif;
